This archive contains licensing and attribution information for the
SD-card .cpfont files distributed with CrossPoint Reader.
Each .cpfont is a converted, size-specific font asset.
